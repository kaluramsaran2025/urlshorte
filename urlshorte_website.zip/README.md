# URLShorte — Cloudflare Pages URL shortener

A responsive English-language URL shortener for `https://urlshorte.pages.dev/`. It includes custom aliases, optional expiry, QR code download, local recent-link history, approximate click counts, private management keys and an abuse-report form.

## Before you deploy

This project needs a Cloudflare D1 database. The website files can be uploaded to Pages, but creating/redirecting short links will not work until the D1 database is created and bound.

### 1. Create the D1 database

Install Node.js, then install Wrangler:

```bash
npm install -g wrangler
wrangler login
wrangler d1 create url_shortener_db
```

Copy the `database_id` shown by the command. Open `wrangler.toml` and replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with that ID.

Apply the database schema:

```bash
wrangler d1 migrations apply url_shortener_db --remote
```

### 2. Deploy to Cloudflare Pages

The Cloudflare Pages project name should be **urlshorte**.

From this project folder, deploy using Wrangler:

```bash
wrangler pages deploy public --project-name urlshorte
```

Wrangler detects the `functions/` directory in the project root when deploying a Pages project from the project directory. If your Wrangler version requires an explicit configuration, run the command from this project root and keep `wrangler.toml` beside `functions/`.

Alternatively, in the Cloudflare dashboard:
1. Open **Workers & Pages → Create → Pages → Connect to Git**.
2. Upload/push this project to a Git repository.
3. Set the production branch (for example `main`).
4. Set build command to blank / no build.
5. Set build output directory to `public`.
6. Ensure the `functions` folder is at the repository root, not inside `public`.

### 3. Bind D1 to Pages

In Cloudflare dashboard open **Workers & Pages → urlshorte → Settings → Functions → D1 database bindings**.
- Variable name: `DB`
- D1 database: `url_shortener_db`
Save and redeploy the project.

The `wrangler.toml` binding is also configured for Wrangler-based deployment. The dashboard binding must use the exact variable name `DB`.

### 4. Verify deployment

Open:
- `https://urlshorte.pages.dev/`
- `https://urlshorte.pages.dev/robots.txt`
- `https://urlshorte.pages.dev/sitemap.xml`

Create a test short link, open it in a private browser tab, and check the analytics using the management key displayed at creation time.

## Google Search Console

The requested verification tag is already included as a static tag in `public/index.html` inside `<head>`:

```html
<meta name="google-site-verification" content="aTgXuZJQnaVqEFcT4vS2f4kaD0UOwN78gClDZKioL80">
```

Deploy the site first. Then open Google Search Console, select the URL-prefix property `https://urlshorte.pages.dev/`, choose **HTML tag**, and click **Verify**. Verification is not automatic; Google must check the deployed page.

## API routes

- `POST /api/shorten` — create a link
- `GET /api/analytics/:code` — private analytics; requires `Authorization: Bearer MANAGEMENT_KEY`
- `DELETE /api/link/:code` — delete; requires the same authorization header
- `POST /api/report` — save an abuse report
- `/:code` — redirect to the destination

## Security notes and limitations

- Only HTTP and HTTPS destination URLs are accepted; the server never fetches the destination URL.
- Custom aliases are validated and reserved routes are blocked.
- Management keys are generated using cryptographic randomness. Only a SHA-256 hash is stored in D1. The key is returned once, so save it securely.
- Rate limiting is stored in D1 by a hashed client IP. This is a basic shared limit, not an advanced bot-management system.
- Click counts are approximate. Redirect requests may include crawlers, preview bots and automated checks.
- Abuse reports are saved in the `abuse_reports` table. The operator must inspect that table and take action; this starter does not provide an operator dashboard or guarantee active moderation.
- The QR code is generated in the browser using QRCode.js loaded from cdnjs. The destination URL is processed client-side by that library.
- Free-tier limits and Cloudflare product features can change. Check your Cloudflare account's current limits before public launch.

## Important

This is a deployable starter project, not a managed hosted service. You are responsible for operating the Cloudflare account, reviewing abuse reports, complying with applicable laws, and keeping the service maintained.
